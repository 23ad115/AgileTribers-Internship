// --- DOM Element Selection ---
const display = document.getElementById('display');
const historyLog = document.getElementById('history-log');
const themeToggle = document.getElementById('theme-toggle');
const clearHistoryBtn = document.getElementById('clear-history');

// --- State ---
let history = [];

// --- Functions ---

// Function to append a value to the display
function appendToDisplay(value) {
    if (display.value === 'Error') {
        clearDisplay();
    }
    display.value += value;
}

// Function to clear the display
function clearDisplay() {
    display.value = '';
}

// Function to delete the last character
function deleteLast() {
    if (display.value === 'Error') {
        clearDisplay();
    } else {
        display.value = display.value.slice(0, -1);
    }
}

// Function to calculate the result
function calculateResult() {
    if (!display.value) return; // Do nothing if display is empty
    
    try {
        const expression = display.value;
        // Use eval() for simplicity. Note: In production apps, it's safer to use a custom parser.
        const result = eval(expression.replace(/\^/g, '**')); // ensure power op works if typed
        
        if (result === Infinity || isNaN(result)) {
            display.value = 'Error';
        } else {
            // Round to avoid floating point inaccuracies
            const roundedResult = Math.round(result * 1e10) / 1e10;
            display.value = roundedResult;
            addToHistory(expression, roundedResult);
        }
    } catch (error) {
        display.value = 'Error';
    }
}

// --- New Feature Functions ---

// Function for Percentage Calculation
function calculatePercentage() {
    if (!display.value || display.value === 'Error') return;
    try {
        display.value = eval(display.value) / 100;
    } catch (error) {
        display.value = 'Error';
    }
}

// Function for Scientific Calculations like Square Root
function applyScientific(func) {
    if (!display.value || display.value === 'Error') return;
    try {
        if (func === 'sqrt') {
            display.value = Math.sqrt(eval(display.value));
        }
    } catch (error) {
        display.value = 'Error';
    }
}

// --- History Log Functions ---
function addToHistory(expression, result) {
    history.push({ expression, result });
    updateHistoryLog();
}

function updateHistoryLog() {
    historyLog.innerHTML = '';
    for (const item of history) {
        const li = document.createElement('li');
        li.textContent = `${item.expression} = ${item.result}`;
        historyLog.prepend(li); // Add new items to the top
    }
}

function clearHistory() {
    history = [];
    updateHistoryLog();
}


// --- Keyboard Input Support ---
function handleKeyboardInput(e) {
    e.preventDefault(); // Prevent default browser actions
    const key = e.key;
    if (/[0-9.]/.test(key)) {
        appendToDisplay(key);
    } else if (/[+\-*/]/.test(key)) {
        appendToDisplay(key);
    } else if (key === '^') {
        appendToDisplay('**');
    } else if (key === '%') {
        calculatePercentage();
    } else if (key === 'Enter' || key === '=') {
        calculateResult();
    } else if (key === 'Backspace') {
        deleteLast();
    } else if (key === 'Escape' || key.toLowerCase() === 'c') {
        clearDisplay();
    } else if (key === '(' || key === ')') {
        appendToDisplay(key);
    }
}


// --- Theme Toggle ---
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    // Save preference to localStorage
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('calculatorTheme', isDarkMode ? 'dark' : 'light');
    themeToggle.checked = isDarkMode;
}

function loadTheme() {
    const savedTheme = localStorage.getItem('calculatorTheme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.checked = true;
    } else {
        document.body.classList.remove('dark-mode');
        themeToggle.checked = false;
    }
}


// --- Event Listeners ---
window.addEventListener('keydown', handleKeyboardInput);
themeToggle.addEventListener('change', toggleTheme);
clearHistoryBtn.addEventListener('click', clearHistory);

// Load the saved theme on page load
document.addEventListener('DOMContentLoaded', loadTheme);
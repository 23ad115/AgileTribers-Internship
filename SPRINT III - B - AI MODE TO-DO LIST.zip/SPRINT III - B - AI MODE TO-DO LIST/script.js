document.addEventListener('DOMContentLoaded', () => {
    // ---ELEMENT SELECTORS---
    const taskInput = document.getElementById('task-input');
    const priorityInput = document.getElementById('task-priority');
    const dueDateInput = document.getElementById('task-due-date');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');
    const searchInput = document.getElementById('search-input');
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const undoContainer = document.getElementById('undo-container');
    const undoBtn = document.getElementById('undo-btn');

    // ---STATE MANAGEMENT---
    let lastDeletedTask = null;
    let undoTimeout = null;
    let currentStatusFilter = 'all';
    let currentPriorityFilter = 'all';

    // ---INITIALIZATION---
    // Load dark mode preference
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }
    
    // ---CORE FUNCTIONS---

    /**
     * Creates and adds a new task to the list based on user inputs.
     */
    function addTask() {
        const taskText = taskInput.value.trim();
        const priority = priorityInput.value;
        const dueDate = dueDateInput.value;

        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        const li = document.createElement('li');
        li.className = `task-item priority-${priority}`;
        li.dataset.priority = priority;
        if (dueDate) {
            li.dataset.dueDate = new Date(dueDate).toISOString();
        }

        // Checkbox
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.addEventListener('change', () => {
            li.classList.toggle('completed');
            filterAndSearchTasks();
        });

        // Task Content (Text and Due Date)
        const taskContentDiv = document.createElement('div');
        taskContentDiv.className = 'task-content';

        const span = document.createElement('span');
        span.className = 'task-text';
        span.textContent = taskText;
        taskContentDiv.appendChild(span);
        
        if (dueDate) {
            const dueDateSpan = document.createElement('div');
            dueDateSpan.className = 'due-date';
            dueDateSpan.innerHTML = `<i class="fas fa-calendar-alt"></i> ${formatDate(new Date(dueDate))}`;
            taskContentDiv.appendChild(dueDateSpan);
        }

        // Action Buttons
        const buttonsDiv = document.createElement('div');
        buttonsDiv.className = 'task-buttons';

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';
        editBtn.textContent = 'Edit';
        editBtn.addEventListener('click', () => editTask(li, taskContentDiv, editBtn));

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-btn';
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', () => deleteTask(li));

        buttonsDiv.appendChild(editBtn);
        buttonsDiv.appendChild(deleteBtn);

        li.appendChild(checkbox);
        li.appendChild(taskContentDiv);
        li.appendChild(buttonsDiv);
        
        taskList.appendChild(li);

        // Reset inputs
        taskInput.value = '';
        dueDateInput.value = '';
        priorityInput.value = 'medium';
        taskInput.focus();
        filterAndSearchTasks();
    }

    /**
     * Toggles a task item between view and edit modes.
     */
    function editTask(li, taskContentDiv, editBtn) {
        const isEditing = editBtn.textContent === 'Save';
        
        if (isEditing) {
            // ---SAVE LOGIC---
            const textInput = taskContentDiv.querySelector('input.task-text');
            const dateInput = taskContentDiv.querySelector('input[type="datetime-local"]');
            const newText = textInput.value.trim();

            if (newText) {
                // Restore original elements
                taskContentDiv.innerHTML = '';
                const newSpan = document.createElement('span');
                newSpan.className = 'task-text';
                newSpan.textContent = newText;
                taskContentDiv.appendChild(newSpan);

                const newDueDate = dateInput.value;
                if(newDueDate) {
                    li.dataset.dueDate = new Date(newDueDate).toISOString();
                    const dueDateSpan = document.createElement('div');
                    dueDateSpan.className = 'due-date';
                    dueDateSpan.innerHTML = `<i class="fas fa-calendar-alt"></i> ${formatDate(new Date(newDueDate))}`;
                    taskContentDiv.appendChild(dueDateSpan);
                } else {
                    delete li.dataset.dueDate;
                }

                editBtn.textContent = 'Edit';
            } else {
                alert("Task text cannot be empty.");
            }
        } else {
            // ---ENTER EDIT MODE LOGIC---
            const currentText = taskContentDiv.querySelector('.task-text').textContent;
            const currentDueDate = li.dataset.dueDate ? new Date(li.dataset.dueDate).toISOString().slice(0, 16) : '';
            
            taskContentDiv.innerHTML = `
                <input type="text" class="task-text" value="${currentText}">
                <input type="datetime-local" value="${currentDueDate}">
            `;
            taskContentDiv.querySelector('input.task-text').focus();
            editBtn.textContent = 'Save';
        }
    }

    /**
     * Handles the deletion of a task with an undo option.
     */
    function deleteTask(li) {
        // If there's a pending undo, finalize that deletion first.
        if (undoTimeout) {
            clearTimeout(undoTimeout);
            finalizeDeletion();
        }

        const taskIndex = Array.from(taskList.children).indexOf(li);
        lastDeletedTask = { element: li, index: taskIndex };

        li.remove();
        filterAndSearchTasks(); // Update view after virtual removal

        // Show undo bar
        undoContainer.classList.remove('hidden');

        // Set timeout to finalize deletion
        undoTimeout = setTimeout(() => {
            finalizeDeletion();
        }, 5000); // 5 seconds to undo
    }
    
    /**
     * Permanently removes the last deleted task from memory.
     */
    function finalizeDeletion() {
        lastDeletedTask = null;
        undoTimeout = null;
        undoContainer.classList.add('hidden');
    }
    
    /**
     * Restores the most recently deleted task.
     */
    function handleUndo() {
        if (lastDeletedTask) {
            // Insert back at the original position
            const referenceNode = taskList.children[lastDeletedTask.index];
            taskList.insertBefore(lastDeletedTask.element, referenceNode);

            clearTimeout(undoTimeout);
            finalizeDeletion();
            filterAndSearchTasks();
        }
    }
    
    /**
     * Filters and searches tasks based on global filter and search term values.
     */
    function filterAndSearchTasks() {
        const searchTerm = searchInput.value.toLowerCase();
        
        Array.from(taskList.children).forEach(li => {
            const taskText = li.querySelector('.task-text').textContent.toLowerCase();
            const isCompleted = li.classList.contains('completed');
            const priority = li.dataset.priority;

            // Conditions
            const matchesSearch = taskText.includes(searchTerm);
            
            const matchesStatus = (currentStatusFilter === 'all') ||
                                  (currentStatusFilter === 'completed' && isCompleted) ||
                                  (currentStatusFilter === 'active' && !isCompleted);
                                  
            const matchesPriority = (currentPriorityFilter === 'all') || (currentPriorityFilter === priority);
            
            // Show or hide
            if (matchesSearch && matchesStatus && matchesPriority) {
                li.style.display = 'flex';
            } else {
                li.style.display = 'none';
            }
        });
    }

    // ---UTILITY FUNCTIONS---
    
    /**
     * Formats a date object into a readable string.
     * @param {Date} date The date to format.
     * @returns {string} The formatted date string.
     */
    function formatDate(date) {
        return date.toLocaleString('en-US', { 
            year: 'numeric', month: 'short', day: 'numeric', 
            hour: 'numeric', minute: '2-digit', hour12: true 
        });
    }
    
    // ---EVENT LISTENERS---
    
    addTaskBtn.addEventListener('click', addTask);
    
    taskInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });

    searchInput.addEventListener('input', filterAndSearchTasks);
    
    document.querySelector('.filter-buttons').addEventListener('click', (e) => {
        if (e.target.classList.contains('filter-btn')) {
            document.querySelector('.filter-btn.active').classList.remove('active');
            e.target.classList.add('active');
            currentStatusFilter = e.target.dataset.filter;
            filterAndSearchTasks();
        }
    });

    document.querySelectorAll('.filter-priority-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelector('.filter-priority-btn.active').classList.remove('active');
            btn.classList.add('active');
            currentPriorityFilter = btn.dataset.priority;
            filterAndSearchTasks();
        });
    });

    darkModeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    });

    undoBtn.addEventListener('click', handleUndo);

});
import React, { useState } from 'react';
import FilterMenu from './components/FilterMenu';
import ProductList from './components/ProductList';
import './style.css';

const products = [
  { id: 1, title: 'Wireless Mouse', price: 25.99, category: 'Electronics', rating: 4.5, stock: 20 },
  { id: 2, title: 'The Great Gatsby', price: 10.50, category: 'Books', rating: 4.8, stock: 30 },
  { id: 3, title: 'Cotton T-Shirt', price: 15.00, category: 'Clothing', rating: 4.2, stock: 50 },
  { id: 4, title: 'Bluetooth Headphones', price: 79.99, category: 'Electronics', rating: 4.7, stock: 15 },
  { id: 5, title: 'To Kill a Mockingbird', price: 12.00, category: 'Books', rating: 4.9, stock: 0 },
  { id: 6, title: 'Denim Jeans', price: 45.50, category: 'Clothing', rating: 4.3, stock: 25 },
  { id: 7, title: 'Smart Watch', price: 199.99, category: 'Electronics', rating: 3.9, stock: 10 },
  { id: 8, title: '1984 by George Orwell', price: 9.99, category: 'Books', rating: 4.7, stock: 22 },
];

function App() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const categories = ['All', ...new Set(products.map(p => p.category))];
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  return (
    <>
      <h1>Product List with Filter</h1>
      <FilterMenu
        categories={categories}
        selectedCategory={selectedCategory}
        onCategoryChange={handleCategoryChange}
        products={products}
      />
      <ProductList
        products={products}
        category={selectedCategory}
      />
    </>
  );
}

export default App;
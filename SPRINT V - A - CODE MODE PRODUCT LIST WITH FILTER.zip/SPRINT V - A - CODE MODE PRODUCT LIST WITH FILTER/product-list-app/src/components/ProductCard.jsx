import React from 'react';

// Receives a single 'product' object as a prop
function ProductCard({ product }) {

  // Dynamically create class names for styling based on product properties
  const cardClasses = [
    'product-card',
    product.category.toLowerCase(), // For category-specific background color
    product.rating > 4.5 ? 'highlight' : '' // Bonus: For highlighting high-rated products
  ].join(' ');

  return (
    <div className={cardClasses}>
      {/* Bonus: Display an "Out of Stock" badge if stock is 0 */}
      {product.stock === 0 && <span className="out-of-stock-badge">Out of Stock</span>}

      <div className="product-card-header">
        <h3>{product.title}</h3>
        <span className="product-category">{product.category}</span>
      </div>
      
      {/* --- THIS IS THE MODIFIED LINE --- */}
      <p className="product-price">₹{product.price.toLocaleString('en-IN')}</p>
      
      <p className="product-rating">Rating: {product.rating} / 5</p>
    </div>
  );
}

export default ProductCard;
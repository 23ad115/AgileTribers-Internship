import React from 'react';

function FilterMenu({ categories, selectedCategory, onCategoryChange, products }) {
  const getProductCount = (category) => {
    if (category === 'All') return products.length;
    return products.filter(p => p.category === category).length;
  };

  return (
    <div className="filter-container">
      {categories.map(category => (
        <button
          key={category}
          className={`filter-btn ${selectedCategory === category ? 'active' : ''}`}
          onClick={() => onCategoryChange(category)}
        >
          {category}
          <span className="product-count">{getProductCount(category)}</span>
        </button>
      ))}
    </div>
  );
}

export default FilterMenu;
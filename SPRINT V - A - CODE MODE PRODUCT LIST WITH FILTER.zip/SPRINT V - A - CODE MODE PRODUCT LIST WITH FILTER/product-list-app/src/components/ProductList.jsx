import React from 'react';
import ProductCard from './ProductCard';

// The ProductList component receives all products and the currently selected category from App.jsx.
// It uses the .filter() method to create a new array containing only the products that match
// the selected category. If "All" is selected, it skips filtering. Finally, it uses .map()
// to render a ProductCard component for each item in the filtered list.

function ProductList({ products, category }) {
  const filteredProducts = category === 'All'
    ? products
    : products.filter(product => product.category === category);

  if (filteredProducts.length === 0) {
    return <p className="fallback-message">No products match the selected category.</p>;
  }

  return (
    <div className="product-list">
      {filteredProducts.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

export default ProductList;
// Get the display element
const display = document.getElementById('display');

// Function to append a value to the display
function appendToDisplay(value) {
    display.value += value;
}

// Function to clear the display
function clearDisplay() {
    display.value = '';
}

// Function to delete the last character
function deleteLast() {
    display.value = display.value.slice(0, -1);
}

// Function to calculate the result
function calculateResult() {
    try {
        // Use eval() for simplicity. Note: In production apps, it's safer to use a custom parser.
        const result = eval(display.value);
        if (result === Infinity || isNaN(result)) {
            display.value = 'Error';
        } else {
            // Round to a certain number of decimal places to handle floating point issues
            display.value = Math.round(result * 100000000) / 100000000;
        }
    } catch (error) {
        display.value = 'Error';
    }
}
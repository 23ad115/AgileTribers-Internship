// src/App.jsx

import React from 'react';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import Features from './components/Features';
import Products from './components/Products';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';

// Define a simple theme for consistency
const theme = createTheme({
  palette: {
    // A neutral color for backgrounds to make content pop
    neutral: {
      main: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: 'Roboto, sans-serif',
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline /> {/* Normalizes CSS across browsers */}
      <Navbar />
      <main>
        <HeroSection />
        <Features />
        <Products />
        <Testimonials />
      </main>
      <Footer />
    </ThemeProvider>
  );
}

export default App;
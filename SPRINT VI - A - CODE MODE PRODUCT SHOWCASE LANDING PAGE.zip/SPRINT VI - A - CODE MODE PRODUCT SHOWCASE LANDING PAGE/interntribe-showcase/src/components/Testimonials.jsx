// src/components/Testimonials.jsx

import React from 'react';
import { Box, Typography, Grid, Container, Paper, Avatar } from '@mui/material';
import { testimonialsData } from '../productData';

const Testimonials = () => {
  return (
    <Box sx={{ py: 8, bgcolor: 'neutral.main' }}>
      <Container maxWidth="md">
        <Typography variant="h4" align="center" gutterBottom>
          What Our Customers Say
        </Typography>
        <Grid container spacing={4} sx={{ mt: 4 }}>
          {testimonialsData.map((testimonial, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Paper elevation={2} sx={{ p: 3, display: 'flex', alignItems: 'center' }}>
                <Avatar sx={{ bgcolor: 'primary.main', mr: 2 }}>{testimonial.avatar}</Avatar>
                <Box>
                  <Typography variant="body1">"{testimonial.testimonial}"</Typography>
                  <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 1 }}>
                    - {testimonial.name}
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Testimonials;
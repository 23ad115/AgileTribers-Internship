// src/components/Features.jsx

import React from 'react';
import { Box, Typography, Grid, Container } from '@mui/material';
import { featuresData } from '../productData';

const Features = () => {
  return (
    <Box sx={{ py: 8, bgcolor: 'neutral.main' }}>
      <Container maxWidth="lg">
        <Typography variant="h4" align="center" gutterBottom>
          Why Choose Us
        </Typography>
        <Grid container spacing={4} sx={{ mt: 4 }}>
          {/* Dynamically render features using arrays and .map() */}
          {featuresData.map((feature, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Box sx={{ textAlign: 'center' }}>
                {feature.icon}
                <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                  {feature.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {feature.description}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Features;
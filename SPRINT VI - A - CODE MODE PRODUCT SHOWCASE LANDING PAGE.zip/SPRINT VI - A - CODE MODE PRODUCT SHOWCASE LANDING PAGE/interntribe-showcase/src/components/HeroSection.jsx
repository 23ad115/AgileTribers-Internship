// src/components/HeroSection.jsx

import React from 'react';
import { Box, Typography, Button, Grid, Container } from '@mui/material';

const HeroSection = () => {
  return (
    <Box
      id="home"
      sx={{
        bgcolor: 'background.paper',
        pt: { xs: 8, md: 12 },
        pb: { xs: 8, md: 12 },
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4} alignItems="center">
          <Grid item xs={12} md={6}>
            <Typography
              component="h1"
              variant="h2"
              align="left"
              color="text.primary"
              gutterBottom
            >
              Discover Your Next Device
            </Typography>
            <Typography variant="h5" align="left" color="text.secondary" paragraph>
              Explore our new line of innovative products, designed to integrate seamlessly into your life. Power, performance, and style combined.
            </Typography>
            <Box sx={{ mt: 4, display: 'flex', justifyContent: { xs: 'center', md: 'flex-start' } }}>
              <Button variant="contained" color="primary" size="large" sx={{ mr: 2 }}>
                Buy Now
              </Button>
              <Button variant="outlined" color="primary" size="large">
                Learn More
              </Button>
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box
              component="img"
              sx={{
                width: '100%',
                height: { xs: 'auto', md: 400 },
                maxHeight: { xs: 300, md: 400 },
                objectFit: 'cover',
                borderRadius: 2,
              }}
              alt="A modern laptop, phone, and tablet on a clean desk."
              src="https://picsum.photos/seed/tech-hero/1200/800"
            />
          </Grid>
          {/* ================================ */}
        </Grid>
      </Container>
    </Box>
  );
};

export default HeroSection;
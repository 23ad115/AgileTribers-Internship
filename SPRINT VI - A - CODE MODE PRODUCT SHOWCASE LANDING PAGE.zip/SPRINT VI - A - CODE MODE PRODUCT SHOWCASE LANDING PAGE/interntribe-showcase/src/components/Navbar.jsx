// src/components/Navbar.jsx

import React from 'react';
import { AppBar, Toolbar, Typography, Box, Button } from '@mui/material';
import ImportantDevicesIcon from '@mui/icons-material/ImportantDevices';

const Navbar = () => {
  return (
    <AppBar position="static">
      <Toolbar>
        {/* Site Logo/Name */}
        <ImportantDevicesIcon sx={{ mr: 1 }} />
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Innovate Core
        </Typography>

        {/* Navigation Links */}
        <Box>
          <Button color="inherit" href="#home">Home</Button>
          <Button color="inherit" href="#products">Products</Button>
          <Button color="inherit" href="#contact">Contact</Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
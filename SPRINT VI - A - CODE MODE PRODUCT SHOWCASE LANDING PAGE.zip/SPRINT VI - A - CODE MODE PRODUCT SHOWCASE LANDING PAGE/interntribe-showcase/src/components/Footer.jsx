// src/components/Footer.jsx

import React from 'react';
import { Box, Typography, Container, IconButton, Link } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';

const Footer = () => {
  return (
    <Box
      id="contact"
      component="footer"
      sx={{
        bgcolor: 'background.paper',
        py: 6,
        borderTop: '1px solid',
        borderColor: 'divider',
      }}
    >
      <Container maxWidth="lg">
        <Typography variant="h6" align="center" gutterBottom>
          Innovate Core
        </Typography>
        <Typography
          variant="subtitle1"
          align="center"
          color="text.secondary"
          component="p"
        >
          Connecting you to the future of technology.
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 2 }}>
          <IconButton
            aria-label="Facebook"
            color="inherit"
            component={Link}
            href="https://facebook.com"
          >
            <FacebookIcon />
          </IconButton>
          <IconButton
            aria-label="Twitter"
            color="inherit"
            component={Link}
            href="https://twitter.com"
          >
            <TwitterIcon />
          </IconButton>
          <IconButton
            aria-label="LinkedIn"
            color="inherit"
            component={Link}
            href="https://linkedin.com"
          >
            <LinkedInIcon />
          </IconButton>
        </Box>
        <Typography variant="body2" color="text.secondary" align="center">
          {'© '}
          {new Date().getFullYear()}
          {' Innovate Core. All rights reserved.'}
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;
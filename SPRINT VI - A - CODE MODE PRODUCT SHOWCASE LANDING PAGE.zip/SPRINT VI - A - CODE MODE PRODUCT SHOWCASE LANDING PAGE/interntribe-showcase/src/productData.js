// src/productData.js

import DevicesIcon from '@mui/icons-material/Devices';
import SpeedIcon from '@mui/icons-material/Speed';
import SecurityIcon from '@mui/icons-material/Security';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';

// Data for the Product Features section
export const featuresData = [
  {
    icon: <DevicesIcon sx={{ fontSize: 40 }} color="primary" />,
    title: 'Cross-Platform',
    description: 'Our products are designed to work seamlessly across all your devices, whether it\'s a phone, tablet, or laptop.',
  },
  {
    icon: <SpeedIcon sx={{ fontSize: 40 }} color="primary" />,
    title: 'Blazing Fast',
    description: 'Experience unparalleled performance and speed with our next-gen hardware and optimized software.',
  },
  {
    icon: <SecurityIcon sx={{ fontSize: 40 }} color="primary" />,
    title: 'Secure by Design',
    description: 'Your privacy and security are our top priorities. Our devices come with state-of-the-art protection.',
  },
  {
    icon: <SupportAgentIcon sx={{ fontSize: 40 }} color="primary" />,
    title: '24/7 Support',
    description: 'Our dedicated support team is always here to help you with any questions or issues, anytime.',
  },
];

// Data for the Product Cards section - with UPDATED images
export const productsData = [
  {
    id: 1,
    name: 'AuraBook Pro 15',
    description: 'The most powerful and versatile laptop for professionals and creatives. Featuring the new M3 Ultra chip.',
    image: 'https://picsum.photos/seed/laptop/600/400',
  },
  {
    id: 2,
    name: 'AuraPhone 12',
    description: 'Capture life\'s moments in stunning detail with a revolutionary new camera system. All-day battery life.',
    image: 'https://picsum.photos/seed/phone/600/400',
  },
  {
    id: 3,
    name: 'AuraTab Lite',
    description: 'Your portable powerhouse for work and play. A stunning Liquid Retina display and powerful A16 chip.',
    image: 'https://picsum.photos/seed/tablet/600/400',
  },
];

// Data for the (Optional) Testimonials section
export const testimonialsData = [
    {
        name: 'Sarah J., Developer',
        testimonial: '"The AuraBook Pro has completely changed my workflow. The speed is incredible and the display is just gorgeous."',
        avatar: 'S', // Using letter for avatar
    },
    {
        name: 'Mark T., Photographer',
        testimonial: '"I take my AuraPhone everywhere. The camera quality is unmatched and it feels great in the hand."',
        avatar: 'M',
    },
];
/*
This script uses async/await to simulate fetching tasks with a delay. Real-time 
progress updates are handled by setInterval and can be paused/resumed individually.
New features include task priority, estimated time remaining, and a completion log.
*/
document.addEventListener("DOMContentLoaded", () => {
    const loadTasksBtn = document.getElementById("loadTasksBtn");
    const startProgressBtn = document.getElementById("startProgressBtn");
    const stopProgressBtn = document.getElementById("stopProgressBtn");
    const delayNotificationBtn = document.getElementById("delayNotificationBtn");
    const taskListContainer = document.getElementById("taskList");
    const notificationPanel = document.getElementById("notification-panel");
    const completionLog = document.getElementById("completion-log");

    let tasks = [];
    let intervalIds = {};

    const fakeTaskData = [
        { id: 1, name: "Designing UI Mockups", progress: 0, status: "Pending", priority: "High" },
        { id: 2, name: "Developing API Endpoints", progress: 0, status: "Pending", priority: "High" },
        { id: 3, name: "Frontend Feature Implementation", progress: 0, status: "Pending", priority: "Medium" },
        { id: 4, name: "Unit & Integration Testing", progress: 0, status: "Pending", priority: "Low" },
    ];

    async function fetchTasks() {
        taskListContainer.innerHTML = "<p>Loading...</p>";
        try {
            const fetchedTasks = await new Promise(resolve => {
                setTimeout(() => resolve(JSON.parse(JSON.stringify(fakeTaskData))), 1500); // Deep copy
            });
            tasks = fetchedTasks;
            renderTasks();
            updateButtonStates();
            addNotification("Tasks loaded successfully.");
        } catch (error) {
            taskListContainer.innerHTML = "<p>Failed to load tasks.</p>";
            addNotification("Error: Could not fetch tasks.", "error");
            console.error(error);
        }
    }

    function renderTasks() {
        taskListContainer.innerHTML = "";
        tasks.forEach(task => {
            const taskElement = document.createElement("div");
            taskElement.className = "task-item status-pending";
            taskElement.id = `task-${task.id}`;
            taskElement.innerHTML = `
                <div class="task-info">
                    <span class="task-name">${task.name}
                        <span class="task-priority priority-${task.priority.toLowerCase()}">${task.priority}</span>
                    </span>
                     <span class="task-etr">ETR: --</span>
                </div>
                <div class="task-controls">
                    <span class="task-status">${task.status}</span>
                    <button class="task-action-btn" data-id="${task.id}">Start</button>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar" style="width: ${task.progress}%;"></div>
                </div>
                <span class="task-progress-percentage">${task.progress}%</span>
            `;
            taskListContainer.appendChild(taskElement);

            taskElement.querySelector(".task-action-btn").addEventListener("click", () => toggleTaskProgress(task.id));
        });
    }

    function startAllTasks() {
        tasks.forEach(task => {
            if (task.status === "Pending") {
                startSingleTask(task);
            }
        });
        addNotification("Started all pending tasks.");
    }
    
    function stopAllTasks() {
        Object.values(intervalIds).forEach(clearInterval);
        intervalIds = {};
        tasks.forEach(task => {
            if (task.status === "In Progress" || task.status === "Paused") {
                task.status = "Pending"; // Revert to Pending, keep progress
                updateTaskUI(task);
            }
        });
        updateButtonStates();
        addNotification("All tasks stopped by user.");
    }
    
    function toggleTaskProgress(taskId) {
        const task = tasks.find(t => t.id === taskId);
        if (!task) return;

        if (task.status === "In Progress") {
            pauseTask(task);
        } else {
            startSingleTask(task);
        }
    }

    function startSingleTask(task) {
        if (task.status === "Completed" || intervalIds[task.id]) return;

        task.status = "In Progress";
        const intervalId = setInterval(() => {
            task.progress += 5; // Slower progress for better visual ETR
            if (task.progress >= 100) {
                task.progress = 100;
                task.status = "Completed";
                clearInterval(intervalId);
                delete intervalIds[task.id];
                addNotification(`Task "${task.name}" completed!`);
                logTaskCompletion(task);
                if (Object.keys(intervalIds).length === 0) {
                   addNotification("All active tasks have been completed!");
                }
            }
            updateTaskUI(task);
            updateButtonStates();
        }, 1000);
        
        intervalIds[task.id] = intervalId;
        updateTaskUI(task);
        updateButtonStates();
    }

    function pauseTask(task) {
        if (!intervalIds[task.id]) return;

        clearInterval(intervalIds[task.id]);
        delete intervalIds[task.id];
        task.status = "Paused";
        updateTaskUI(task);
        updateButtonStates();
    }
    
    function updateTaskUI(task) {
        const taskElement = document.getElementById(`task-${task.id}`);
        if (!taskElement) return;

        // Update Status & Progress
        taskElement.querySelector(".task-status").textContent = task.status;
        taskElement.querySelector(".task-progress-percentage").textContent = `${task.progress}%`;
        taskElement.querySelector(".progress-bar").style.width = `${task.progress}%`;
        
        // Update ETR
        taskElement.querySelector(".task-etr").textContent = `ETR: ${calculateETR(task)}`;

        // Update Class Name for styling
        taskElement.className = "task-item"; // Reset classes
        taskElement.classList.add(`status-${task.status.toLowerCase().replace(' ', '-')}`);

        // Update Action Button
        const actionBtn = taskElement.querySelector(".task-action-btn");
        actionBtn.disabled = false;
        if (task.status === "In Progress") {
            actionBtn.textContent = "Pause";
        } else if (task.status === "Paused" || task.status === "Pending") {
            actionBtn.textContent = "Resume";
        }
        if(task.status === "Pending") actionBtn.textContent = "Start";
        if(task.status === "Completed"){
            actionBtn.textContent = "Done";
            actionBtn.disabled = true;
        }
    }
    
    function calculateETR(task) {
        if (task.status !== "In Progress") return "--";
        const remainingProgress = 100 - task.progress;
        const secondsPerStep = 1; // Corresponds to setInterval duration
        const progressPerStep = 5;  // Corresponds to progress increment
        const stepsLeft = Math.ceil(remainingProgress / progressPerStep);
        return `${stepsLeft * secondsPerStep}s`;
    }

    function logTaskCompletion(task) {
        const p = document.createElement("p");
        const timestamp = new Date().toLocaleTimeString();
        p.innerHTML = `[${timestamp}] - Task "<strong>${task.name}</strong>" completed.`;
        completionLog.insertBefore(p, completionLog.firstChild);
    }
    
    function showDelayedNotification() {
        addNotification("A delayed notification will appear in 3 seconds...");
        setTimeout(() => {
            addNotification("This is the delayed notification!");
        }, 3000);
    }
    
    function addNotification(message) {
        const p = document.createElement("p");
        p.textContent = message;
        notificationPanel.insertBefore(p, notificationPanel.firstChild);
    }
    
    function updateButtonStates() {
        const isProgressRunning = Object.keys(intervalIds).length > 0;
        const hasPendingTasks = tasks.some(t => t.status === 'Pending' || t.status === 'Paused');
        startProgressBtn.disabled = tasks.length === 0 || isProgressRunning || !hasPendingTasks;
        stopProgressBtn.disabled = !isProgressRunning;
    }

    // --- Event Listeners ---
    loadTasksBtn.addEventListener("click", fetchTasks);
    startProgressBtn.addEventListener("click", startAllTasks);
    stopProgressBtn.addEventListener("click", stopAllTasks);
    delayNotificationBtn.addEventListener("click", showDelayedNotification);

    // Initial State
    updateButtonStates();
});
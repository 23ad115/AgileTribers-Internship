document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const userTableBody = document.getElementById('table-body');
    const searchInput = document.getElementById('search-input');
    const addUserBtn = document.getElementById('add-user-btn');
    const tableHeaders = document.querySelectorAll('#user-table th[data-column]');
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const pageInfo = document.getElementById('page-info');

    // App State
    let allUsers = [];
    let filteredUsers = [];
    let sortConfig = { key: 'name', direction: 'ascending' };
    let currentPage = 1;
    const rowsPerPage = 5;
    const apiUrl = 'https://jsonplaceholder.typicode.com/users';

    // --- DATA FETCHING ---
    const fetchUsers = async () => {
        try {
            const response = await fetch(apiUrl);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            allUsers = await response.json();
            updateDisplay();
        } catch (error) {
            console.error("Could not fetch user data:", error);
            userTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Failed to load data.</td></tr>`;
        }
    };

    // --- CORE DISPLAY LOGIC ---
    const updateDisplay = () => {
        applyFilters();
        applySorting();
        renderTablePage();
        renderPagination();
    };

    const applyFilters = () => {
        const searchTerm = searchInput.value.toLowerCase();
        filteredUsers = allUsers.filter(user =>
            user.name.toLowerCase().includes(searchTerm) ||
            user.email.toLowerCase().includes(searchTerm) ||
            user.username.toLowerCase().includes(searchTerm) ||
            user.phone.toLowerCase().includes(searchTerm)
        );
    };

    const applySorting = () => {
        filteredUsers.sort((a, b) => {
            const valA = String(a[sortConfig.key] || '').toLowerCase();
            const valB = String(b[sortConfig.key] || '').toLowerCase();
            if (valA < valB) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (valA > valB) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });
        updateSortHeadersUI();
    };

    // --- UI RENDERING ---
    const renderTablePage = () => {
        userTableBody.innerHTML = '';
        const startIndex = (currentPage - 1) * rowsPerPage;
        const endIndex = startIndex + rowsPerPage;
        const pageUsers = filteredUsers.slice(startIndex, endIndex);

        if (pageUsers.length === 0 && searchInput.value) {
            userTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center;">No users match your search.</td></tr>`;
            return;
        }

        pageUsers.forEach(user => {
            const row = document.createElement('tr');
            row.dataset.userId = user.id; // Store user ID for future reference
            row.innerHTML = `
                <td data-field="name">${user.name}</td>
                <td data-field="email">${user.email}</td>
                <td data-field="username">${user.username}</td>
                <td data-field="phone">${user.phone}</td>
                <td>
                    <button class="action-btn edit-btn">Edit</button>
                    <button class="action-btn delete-btn">Delete</button>
                </td>
            `;
            userTableBody.appendChild(row);
        });
    };

    const renderPagination = () => {
        const totalPages = Math.ceil(filteredUsers.length / rowsPerPage);
        pageInfo.textContent = totalPages > 0 ? `Page ${currentPage} of ${totalPages}` : 'No data';
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    };
    
    const updateSortHeadersUI = () => {
        tableHeaders.forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
            if (header.dataset.column === sortConfig.key) {
                header.classList.add(sortConfig.direction === 'ascending' ? 'sort-asc' : 'sort-desc');
            }
        });
    };

    // --- USER ACTIONS ---
    const addNewUserRow = () => {
        const newRow = document.createElement('tr');
        newRow.classList.add('new-user-row');
        newRow.innerHTML = `
            <td data-field="name" contenteditable="true" placeholder="Name"></td>
            <td data-field="email" contenteditable="true" placeholder="Email"></td>
            <td data-field="username" contenteditable="true" placeholder="Username"></td>
            <td data-field="phone" contenteditable="true" placeholder="Phone"></td>
            <td>
                <button class="action-btn save-btn">Save</button>
                <button class="action-btn delete-btn">Cancel</button>
            </td>
        `;
        userTableBody.prepend(newRow);
        newRow.querySelector('td').focus();
    };
    
    const toggleEditMode = (row, button) => {
        const cellsToEdit = row.querySelectorAll('td[data-field]');
        cellsToEdit.forEach(cell => {
            cell.contentEditable = true;
            cell.classList.add('editable');
        });
        button.textContent = 'Save';
        button.classList.remove('edit-btn');
        button.classList.add('save-btn');
    };
    
    const saveChanges = (row, button) => {
        const cellsToEdit = row.querySelectorAll('td[data-field]');
        // For existing users
        if (row.dataset.userId) {
            const userId = parseInt(row.dataset.userId);
            const userIndex = allUsers.findIndex(u => u.id === userId);
            if (userIndex > -1) {
                cellsToEdit.forEach(cell => {
                    const field = cell.dataset.field;
                    allUsers[userIndex][field] = cell.textContent.trim();
                });
            }
        // For new users
        } else {
             const newUser = { id: Date.now() }; // Create a temporary unique ID
             let isValid = true;
             cellsToEdit.forEach(cell => {
                newUser[cell.dataset.field] = cell.textContent.trim();
                if (!newUser[cell.dataset.field]) isValid = false;
            });
            if (!isValid) {
                alert('All fields must be filled out to save a new user.');
                return;
            }
            allUsers.unshift(newUser);
        }
        
        // Update UI and re-render everything
        updateDisplay();
    };

    // --- EVENT LISTENERS ---
    searchInput.addEventListener('input', () => {
        currentPage = 1;
        updateDisplay();
    });

    tableHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const key = header.dataset.column;
            if (sortConfig.key === key) {
                sortConfig.direction = sortConfig.direction === 'ascending' ? 'descending' : 'ascending';
            } else {
                sortConfig.key = key;
                sortConfig.direction = 'ascending';
            }
            updateDisplay();
        });
    });

    addUserBtn.addEventListener('click', addNewUserRow);
    
    prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderTablePage();
            renderPagination();
        }
    });

    nextPageBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredUsers.length / rowsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderTablePage();
            renderPagination();
        }
    });

    userTableBody.addEventListener('click', (event) => {
        const target = event.target;
        const row = target.closest('tr');
        if (!row) return;

        // Delete/Cancel button
        if (target.classList.contains('delete-btn')) {
            if (row.classList.contains('new-user-row')) {
                row.remove(); // Just cancel the new entry
            } else {
                if (confirm('Are you sure you want to delete this user?')) {
                    const userId = parseInt(row.dataset.userId);
                    allUsers = allUsers.filter(user => user.id !== userId);
                    updateDisplay();
                }
            }
        } 
        // Edit button
        else if (target.classList.contains('edit-btn')) {
            toggleEditMode(row, target);
        } 
        // Save button (for new or existing rows)
        else if (target.classList.contains('save-btn')) {
            saveChanges(row, target);
        }
    });

    // Initial Load
    fetchUsers();
});
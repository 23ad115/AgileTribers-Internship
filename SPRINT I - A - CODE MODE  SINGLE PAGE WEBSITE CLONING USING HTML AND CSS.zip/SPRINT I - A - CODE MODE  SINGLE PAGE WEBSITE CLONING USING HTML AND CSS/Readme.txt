Wikipedia single Homepage Clone

This is a static clone of the Wikipedia.org landing page, built using only HTML and CSS.

The project was created to demonstrate skills in front-end development, focusing on semantic HTML structure and modern CSS for layout and styling.

Technologies Used

*   HTML5
*   CSS3

How to View

1.  Download the project folder.
2.  Make sure you have an images folder with all the required logos.
3.  Open the index.html file in any web browser.

Original Website: [https://www.wikipedia.org/]
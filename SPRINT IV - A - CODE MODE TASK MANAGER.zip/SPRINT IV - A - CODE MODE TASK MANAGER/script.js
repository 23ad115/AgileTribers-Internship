/*
This script uses async/await to simulate fetching tasks with a delay. Real-time 
progress updates are handled by setInterval and can be stopped with clearInterval.
*/
document.addEventListener("DOMContentLoaded", () => {
    const loadTasksBtn = document.getElementById("loadTasksBtn");
    const startProgressBtn = document.getElementById("startProgressBtn");
    const stopProgressBtn = document.getElementById("stopProgressBtn");
    const delayNotificationBtn = document.getElementById("delayNotificationBtn");
    const taskListContainer = document.getElementById("taskList");
    const notificationPanel = document.getElementById("notification-panel");

    let tasks = [];
    let intervalIds = {};
    let isProgressRunning = false;

    const fakeTaskData = [
        { id: 1, name: "Designing UI Mockups", progress: 0, status: "Pending" },
        { id: 2, name: "Developing API Endpoints", progress: 0, status: "Pending" },
        { id: 3, name: "Frontend Feature Implementation", progress: 0, status: "Pending" },
        { id: 4, name: "Unit & Integration Testing", progress: 0, status: "Pending" },
    ];

    async function fetchTasks() {
        taskListContainer.innerHTML = "<p>Loading...</p>";
        
        try {
            const fetchedTasks = await new Promise(resolve => {
                setTimeout(() => {
                    resolve(fakeTaskData);
                }, 1500);
            });

            tasks = fetchedTasks;
            renderTasks();
            updateButtonStates();
            addNotification("Tasks loaded successfully.");

        } catch (error) {
            taskListContainer.innerHTML = "<p>Failed to load tasks.</p>";
            addNotification("Error: Could not fetch tasks.", "error");
            console.error(error);
        }
    }

    function renderTasks() {
        taskListContainer.innerHTML = "";
        tasks.forEach(task => {
            const taskElement = document.createElement("div");
            taskElement.className = "task-item status-pending";
            taskElement.id = `task-${task.id}`;
            
            taskElement.innerHTML = `
                <div class="task-info">
                    <span class="task-name">${task.name}</span>
                    <span class="task-status">${task.status}</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar" style="width: ${task.progress}%;"></div>
                </div>
                <span class="task-progress-percentage">${task.progress}%</span>
            `;
            taskListContainer.appendChild(taskElement);
        });
    }

    function startProgress() {
        if (isProgressRunning) return;
        isProgressRunning = true;
        updateButtonStates();

        tasks.forEach(task => {
            if (task.status !== "Completed") {
                task.status = "In Progress";
                updateTaskUI(task);

                const intervalId = setInterval(() => {
                    task.progress += 10;
                    if (task.progress >= 100) {
                        task.progress = 100;
                        task.status = "Completed";
                        clearInterval(intervalId);
                        delete intervalIds[task.id];
                        if (Object.keys(intervalIds).length === 0) {
                           isProgressRunning = false;
                           updateButtonStates();
                           addNotification("All tasks have been completed!");
                        }
                    }
                    updateTaskUI(task);
                }, 1000);
                
                intervalIds[task.id] = intervalId;
            }
        });
        addNotification("Task progress started.");
    }
    
    function stopProgress() {
        isProgressRunning = false;
        Object.values(intervalIds).forEach(clearInterval);
        intervalIds = {};
        
        tasks.forEach(task => {
            if (task.status === "In Progress") {
                task.status = "Pending";
                updateTaskUI(task);
            }
        });
        
        updateButtonStates();
        addNotification("Task progress stopped by user.");
    }

    function updateTaskUI(task) {
        const taskElement = document.getElementById(`task-${task.id}`);
        if (!taskElement) return;

        taskElement.querySelector(".task-status").textContent = task.status;
        taskElement.querySelector(".task-progress-percentage").textContent = `${task.progress}%`;
        taskElement.querySelector(".progress-bar").style.width = `${task.progress}%`;
        
        taskElement.className = "task-item";
        if (task.status === "In Progress") {
            taskElement.classList.add("status-in-progress");
        } else if (task.status === "Completed") {
            taskElement.classList.add("status-completed");
        } else {
             taskElement.classList.add("status-pending");
        }
    }
    
    function showDelayedNotification() {
        addNotification("A delayed notification will appear in 3 seconds...");
        setTimeout(() => {
            addNotification("This is the delayed notification!");
        }, 3000);
    }
    
    function addNotification(message) {
        const p = document.createElement("p");
        p.textContent = message;
        notificationPanel.insertBefore(p, notificationPanel.firstChild);
    }
    
    function updateButtonStates() {
        startProgressBtn.disabled = tasks.length === 0 || isProgressRunning;
        stopProgressBtn.disabled = !isProgressRunning;
    }

    loadTasksBtn.addEventListener("click", fetchTasks);
    startProgressBtn.addEventListener("click", startProgress);
    stopProgressBtn.addEventListener("click", stopProgress);
    delayNotificationBtn.addEventListener("click", showDelayedNotification);

    updateButtonStates();
});
document.addEventListener('DOMContentLoaded', () => {
    const employees = [
        { id: 1, name: "Alice Johnson", age: 28, department: "Engineering", role: "Software Engineer", salary: 95000 },
        { id: 2, name: "Bob Smith", age: 34, department: "Marketing", role: "Marketing Manager", salary: 85000 },
        { id: 3, name: "Charlie Brown", age: 42, department: "Engineering", role: "Senior Engineer", salary: 120000 },
        { id: 4, name: "Diana Prince", age: 30, department: "Sales", role: "Sales Associate", salary: 75000 },
        { id: 5, name: "Ethan Hunt", age: 25, department: "HR", role: "Recruiter", salary: 60000 },
        { id: 6, name: "Fiona Glenanne", age: 38, department: "Engineering", role: "Project Manager", salary: 110000 },
        { id: 7, name: "George Costanza", age: 45, department: "Sales", role: "Sales Director", salary: 130000 },
        { id: 8, name: "Hannah Montana", age: 29, department: "Marketing", role: "Content Creator", salary: 65000 }
    ];

    let currentEmployees = [...employees];

    const employeeTableBody = document.getElementById('employee-table-body');
    const departmentFilter = document.getElementById('department-filter');
    const searchInput = document.getElementById('search-input');
    const calcAvgSalaryBtn = document.getElementById('calc-avg-salary-btn');
    const namesUppercaseBtn = document.getElementById('names-uppercase-btn');
    const averageSalarySpan = document.getElementById('average-salary');
    const searchedEmployeeInfo = document.getElementById('searched-employee-info');
    const totalEmployeesSpan = document.getElementById('total-employees');
    const themeToggleBtn = document.getElementById('theme-toggle-btn');

    const renderTable = (employeeArray) => {
        employeeTableBody.innerHTML = '';
        employeeArray.forEach(emp => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${emp.name}</td>
                <td>${emp.age}</td>
                <td>${emp.department}</td>
                <td>${emp.role}</td>
                <td>$${emp.salary.toLocaleString()}</td>
            `;
            employeeTableBody.appendChild(row);
        });
        totalEmployeesSpan.textContent = employeeArray.length;
    };

    const populateDepartments = () => {
        const departments = new Set(employees.map(emp => emp.department));
        departments.forEach(dept => {
            const option = document.createElement('option');
            option.value = dept;
            option.textContent = dept;
            departmentFilter.appendChild(option);
        });
    };

    const filterByDepartment = () => {
        const selectedDepartment = departmentFilter.value;
        if (selectedDepartment === 'all') {
            currentEmployees = [...employees];
        } else {
            currentEmployees = employees.filter(emp => emp.department === selectedDepartment);
        }
        renderTable(currentEmployees);
        averageSalarySpan.textContent = 'N/A';
        searchedEmployeeInfo.innerHTML = '';
    };

    const searchByName = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const foundEmployee = employees.find(emp => emp.name.toLowerCase().includes(searchTerm));

        if (foundEmployee) {
            searchedEmployeeInfo.innerHTML = `
                <strong>Found:</strong> ${foundEmployee.name} - ${foundEmployee.role} ($${foundEmployee.salary.toLocaleString()})
            `;
        } else if (searchTerm) {
            searchedEmployeeInfo.innerHTML = `<strong style="color: #e53e3e;">No match found.</strong>`;
        } else {
            searchedEmployeeInfo.innerHTML = '';
        }
    };

    const calculateAverageSalary = () => {
        if (currentEmployees.length === 0) {
            averageSalarySpan.textContent = '$0';
            return;
        }
        const totalSalary = currentEmployees.reduce((accumulator, employee) => accumulator + employee.salary, 0);
        const average = totalSalary / currentEmployees.length;
        averageSalarySpan.textContent = `$${average.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    };

    const convertNamesToUppercase = () => {
        currentEmployees = currentEmployees.map(emp => ({ ...emp, name: emp.name.toUpperCase() }));
        renderTable(currentEmployees);
    };

    const toggleTheme = () => {
        document.body.classList.toggle('dark-mode');
    };

    populateDepartments();
    renderTable(currentEmployees);

    departmentFilter.addEventListener('change', filterByDepartment);
    searchInput.addEventListener('input', searchByName);
    calcAvgSalaryBtn.addEventListener('click', calculateAverageSalary);
    namesUppercaseBtn.addEventListener('click', convertNamesToUppercase);
    themeToggleBtn.addEventListener('click', toggleTheme);
});
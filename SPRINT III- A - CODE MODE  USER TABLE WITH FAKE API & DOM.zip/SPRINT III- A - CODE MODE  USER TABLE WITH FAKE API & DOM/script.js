document.addEventListener('DOMContentLoaded', () => {
    const userTableBody = document.getElementById('table-body');
    const apiUrl = 'https://jsonplaceholder.typicode.com/users';

    const fetchUsers = async () => {
        try {
            const response = await fetch(apiUrl);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const users = await response.json();
            renderTable(users);
        } catch (error) {
            console.error("Could not fetch user data:", error);
            userTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center;">Failed to load data.</td></tr>`;
        }
    };

    const renderTable = (users) => {
        userTableBody.innerHTML = '';
        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td data-field="name">${user.name}</td>
                <td data-field="email">${user.email}</td>
                <td data-field="username">${user.username}</td>
                <td data-field="phone">${user.phone}</td>
                <td>
                    <button class="action-btn edit-btn">Edit</button>
                    <button class="action-btn delete-btn">Delete</button>
                </td>
            `;
            userTableBody.appendChild(row);
        });
    };

    userTableBody.addEventListener('click', (event) => {
        const target = event.target;
        const row = target.closest('tr');
        if (!row) return;

        if (target.classList.contains('delete-btn')) {
            row.remove();
        }

        if (target.classList.contains('edit-btn')) {
            toggleEditMode(row, target);
        } else if (target.classList.contains('save-btn')) {
            toggleEditMode(row, target);
        }
    });

    const toggleEditMode = (row, button) => {
        const isEditing = button.classList.contains('edit-btn');
        const cellsToEdit = row.querySelectorAll('td[data-field]');
        
        cellsToEdit.forEach(cell => {
            cell.contentEditable = isEditing;
            cell.classList.toggle('editable', isEditing);
        });

        button.textContent = isEditing ? 'Save' : 'Edit';
        button.classList.toggle('edit-btn');
        button.classList.toggle('save-btn');
    };

    fetchUsers();
});
import React from 'react';

const UserCard = ({ name, email, age, role }) => {
  const getRoleClass = () => {
    switch (role.toLowerCase()) {
      case 'admin':
        return 'role-admin';
      case 'member':
        return 'role-member';
      case 'guest':
        return 'role-guest';
      default:
        return 'role-guest';
    }
  };
  
  const cardClasses = `user-card ${age < 18 ? 'underage' : ''}`;

  return (
    <div className={cardClasses}>
      <h3>{name}</h3>
      <p><strong>Email:</strong> {email}</p>
      <p><strong>Age:</strong> {age}</p>
      <div className={`role-badge ${getRoleClass()}`}>
        {role}
      </div>
    </div>
  );
};

export default UserCard;
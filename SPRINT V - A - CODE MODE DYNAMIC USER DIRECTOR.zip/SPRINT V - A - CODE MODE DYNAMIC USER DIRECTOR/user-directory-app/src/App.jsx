import React, { useState } from 'react';
import UserList from './components/UserList';
import './style.css';

function App() {
  const allUsers = [
    { id: 1, name: 'Alice Johnson', email: 'alice.j@example.com', age: 28, role: 'Admin' },
    { id: 2, name: 'Bob Smith', email: 'bob.s@example.com', age: 45, role: 'Member' },
    { id: 3, name: 'Charlie Brown', email: 'charlie.b@example.com', age: 17, role: 'Member' },
    { id: 4, name: 'Diana Prince', email: 'diana.p@example.com', age: 32, role: 'Guest' },
    { id: 5, name: 'Ethan Hunt', email: 'ethan.h@example.com', age: 38, role: 'Admin' },
    { id: 6, name: 'Fiona Glenanne', email: 'fiona.g@example.com', age: 16, role: 'Guest' },
  ];
  
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };
  
  const filteredUsers = allUsers.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="App">
      <header className="header">
        <h1>Dynamic User Directory</h1>
      </header>
      
      <main>
        <div className="controls">
            <input
                type="text"
                placeholder="Search by name..."
                className="search-box"
                value={searchTerm}
                onChange={handleSearchChange}
            />
        </div>

        <UserList users={filteredUsers} />
      </main>
    </div>
  );
}

export default App;
function displayTime() {
    const now = new Date();
    
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();
    let session = 'AM';

    if (hours >= 12) {
        session = 'PM';
    }
    if (hours > 12) {
        hours = hours - 12;
    }
    if (hours === 0) {
        hours = 12;
    }

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;
    
    const hoursElem = document.getElementById('hours');
    const minutesElem = document.getElementById('minutes');
    const secondsElem = document.getElementById('seconds');
    const sessionElem = document.getElementById('session');

    hoursElem.innerText = hours;
    minutesElem.innerText = minutes;
    secondsElem.innerText = seconds;
    sessionElem.innerText = session;
}

displayTime();
setInterval(displayTime, 1000);
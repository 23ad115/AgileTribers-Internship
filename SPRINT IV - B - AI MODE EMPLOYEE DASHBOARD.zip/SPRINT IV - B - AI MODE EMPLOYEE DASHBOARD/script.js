document.addEventListener('DOMContentLoaded', () => {
    // --- MASTER DATA & STATE MANAGEMENT ---
    let employees = [
        { id: 1, name: "Alice Johnson", age: 28, department: "Engineering", role: "Software Engineer", salary: 95000 },
        { id: 2, name: "Bob Smith", age: 34, department: "Marketing", role: "Marketing Manager", salary: 85000 },
        { id: 3, name: "Charlie Brown", age: 42, department: "Engineering", role: "Senior Engineer", salary: 120000 },
        { id: 4, name: "Diana Prince", age: 30, department: "Sales", role: "Sales Associate", salary: 75000 },
        { id: 5, name: "Ethan Hunt", age: 25, department: "HR", role: "Recruiter", salary: 60000 },
        { id: 6, name: "Fiona Glenanne", age: 38, department: "Engineering", role: "Project Manager", salary: 110000 },
        { id: 7, name: "George Costanza", age: 45, department: "Sales", role: "Sales Director", salary: 130000 },
        { id: 8, name: "Hannah Montana", age: 29, department: "Marketing", role: "Content Creator", salary: 65000 }
    ];

    let currentEmployees = [...employees];
    let editingEmployeeId = null;
    let sortState = { column: null, direction: 'asc' };
    let paginationState = { currentPage: 1, pageSize: 5 };

    // --- DOM ELEMENT SELECTORS ---
    const employeeTableBody = document.getElementById('employee-table-body');
    const departmentFilter = document.getElementById('department-filter');
    const searchInput = document.getElementById('search-input');
    const calcAvgSalaryBtn = document.getElementById('calc-avg-salary-btn');
    const namesUppercaseBtn = document.getElementById('names-uppercase-btn');
    const averageSalarySpan = document.getElementById('average-salary');
    const totalEmployeesSpan = document.getElementById('total-employees');
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const exportCsvBtn = document.getElementById('export-csv-btn');
    const sortableHeaders = document.querySelectorAll('th.sortable');

    // Pagination elements
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const pageInfo = document.getElementById('page-info');

    // Department summary elements
    const departmentSummaryContent = document.getElementById('department-summary-content');

    // Add/Edit Form elements
    const employeeFormContainer = document.getElementById('employee-form-container');
    const employeeForm = document.getElementById('employee-form');
    const formTitle = document.getElementById('form-title');
    const addEmployeeBtn = document.getElementById('add-employee-btn');
    const cancelBtn = document.getElementById('cancel-btn');


    // --- CORE RENDERING & UPDATE LOGIC ---

    const updateDisplay = () => {
        // 1. Filter
        let filteredEmployees = employees.filter(emp => {
            const matchesDept = departmentFilter.value === 'all' || emp.department === departmentFilter.value;
            const matchesSearch = emp.name.toLowerCase().includes(searchInput.value.toLowerCase().trim());
            return matchesDept && matchesSearch;
        });

        // 2. Sort
        if (sortState.column) {
            filteredEmployees.sort((a, b) => {
                const valA = a[sortState.column];
                const valB = b[sortState.column];
                if (valA < valB) return sortState.direction === 'asc' ? -1 : 1;
                if (valA > valB) return sortState.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }
        currentEmployees = filteredEmployees;

        // 3. Render
        renderTable();
        renderPagination();
        updateSummary();
    };

    const renderTable = () => {
        employeeTableBody.innerHTML = '';
        const { currentPage, pageSize } = paginationState;
        const start = (currentPage - 1) * pageSize;
        const end = start + pageSize;
        const paginatedEmployees = currentEmployees.slice(start, end);

        if (paginatedEmployees.length === 0) {
            employeeTableBody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No employees found.</td></tr>';
            return;
        }

        paginatedEmployees.forEach(emp => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${emp.name}</td>
                <td>${emp.age}</td>
                <td>${emp.department}</td>
                <td>${emp.role}</td>
                <td>$${emp.salary.toLocaleString()}</td>
                <td class="action-buttons">
                    <button class="edit-btn" data-id="${emp.id}">Edit</button>
                    <button class="delete-btn" data-id="${emp.id}">Delete</button>
                </td>
            `;
            employeeTableBody.appendChild(row);
        });
    };


    // --- FEATURE IMPLEMENTATIONS ---

    // 1. Initial Population
    const populateDepartments = () => {
        departmentFilter.innerHTML = '<option value="all">All Departments</option>'; // Reset
        const departments = [...new Set(employees.map(emp => emp.department))].sort();
        departments.forEach(dept => {
            const option = document.createElement('option');
            option.value = dept;
            option.textContent = dept;
            departmentFilter.appendChild(option);
        });
    };

    // 2. Summary Panels
    const updateSummary = () => {
        totalEmployeesSpan.textContent = currentEmployees.length;
        averageSalarySpan.textContent = 'N/A';
        renderDepartmentSummary();
    };

    const calculateAverageSalary = () => {
        if (currentEmployees.length === 0) {
            averageSalarySpan.textContent = '$0.00';
            return;
        }
        const totalSalary = currentEmployees.reduce((acc, emp) => acc + emp.salary, 0);
        const average = totalSalary / currentEmployees.length;
        averageSalarySpan.textContent = `$${average.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    };

    const renderDepartmentSummary = () => {
        departmentSummaryContent.innerHTML = '';
        const summary = employees.reduce((acc, emp) => {
            if (!acc[emp.department]) {
                acc[emp.department] = { count: 0, totalSalary: 0 };
            }
            acc[emp.department].count++;
            acc[emp.department].totalSalary += emp.salary;
            return acc;
        }, {});

        Object.keys(summary).sort().forEach(dept => {
            const avgSalary = summary[dept].totalSalary / summary[dept].count;
            const summaryDiv = document.createElement('div');
            summaryDiv.innerHTML = `
                <strong>${dept}:</strong>
                <span>${summary[dept].count} Employees / Avg. Sal: $${avgSalary.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            `;
            departmentSummaryContent.appendChild(summaryDiv);
        });
    };
    
    // 3. Sorting
    const handleSort = (e) => {
        const newColumn = e.target.dataset.sort;
        if (sortState.column === newColumn) {
            sortState.direction = sortState.direction === 'asc' ? 'desc' : 'asc';
        } else {
            sortState.column = newColumn;
            sortState.direction = 'asc';
        }
        
        // Update visual indicators
        sortableHeaders.forEach(th => th.querySelector('span').textContent = '');
        const indicator = sortState.direction === 'asc' ? '▲' : '▼';
        e.target.querySelector('span').textContent = indicator;
        
        updateDisplay();
    };

    // 4. Pagination
    const renderPagination = () => {
        const { currentPage, pageSize } = paginationState;
        const totalPages = Math.ceil(currentEmployees.length / pageSize);

        if (totalPages <= 1) {
            pageInfo.parentElement.style.display = 'none';
            return;
        }
        
        pageInfo.parentElement.style.display = 'flex';
        pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentPage === totalPages;
    };
    
    // 5. Add/Edit/Delete (CRUD)
    const showForm = () => {
        employeeFormContainer.style.display = 'block';
    };

    const hideForm = () => {
        employeeForm.reset();
        employeeFormContainer.style.display = 'none';
        editingEmployeeId = null;
        formTitle.textContent = "Add New Employee";
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        const employeeData = {
            id: editingEmployeeId ? Number(editingEmployeeId) : Date.now(), // new unique ID
            name: document.getElementById('name').value,
            age: parseInt(document.getElementById('age').value),
            department: document.getElementById('department').value,
            role: document.getElementById('role').value,
            salary: parseInt(document.getElementById('salary').value),
        };

        if (editingEmployeeId) { // Editing
            const index = employees.findIndex(emp => emp.id === editingEmployeeId);
            employees[index] = employeeData;
        } else { // Adding
            employees.push(employeeData);
        }

        hideForm();
        populateDepartments(); // Refresh departments if a new one was added
        updateDisplay();
    };

    const handleTableActions = (e) => {
        const target = e.target;
        const id = parseInt(target.dataset.id);
        
        if (target.classList.contains('delete-btn')) {
            if (confirm('Are you sure you want to delete this employee?')) {
                employees = employees.filter(emp => emp.id !== id);
                updateDisplay();
            }
        }
        
        if (target.classList.contains('edit-btn')) {
            const employeeToEdit = employees.find(emp => emp.id === id);
            editingEmployeeId = id;
            formTitle.textContent = "Edit Employee";
            document.getElementById('employee-id').value = employeeToEdit.id;
            document.getElementById('name').value = employeeToEdit.name;
            document.getElementById('age').value = employeeToEdit.age;
            document.getElementById('department').value = employeeToEdit.department;
            document.getElementById('role').value = employeeToEdit.role;
            document.getElementById('salary').value = employeeToEdit.salary;
            showForm();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };
    
    // 6. CSV Export
    const exportToCsv = () => {
        if (currentEmployees.length === 0) return;
        
        const headers = "Name,Age,Department,Role,Salary\n";
        const rows = currentEmployees.map(emp =>
            `${emp.name},${emp.age},${emp.department},${emp.role},${emp.salary}`
        ).join('\n');

        const csvContent = headers + rows;
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "employees.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // 7. Misc Features (Uppercase names, Theme Toggle)
    const convertNamesToUppercase = () => {
        employees = employees.map(emp => ({ ...emp, name: emp.name.toUpperCase() }));
        updateDisplay();
    };

    const toggleTheme = () => {
        document.body.classList.toggle('dark-mode');
    };
    
    // --- EVENT LISTENERS ---
    
    // Controls
    departmentFilter.addEventListener('change', () => {
        paginationState.currentPage = 1;
        updateDisplay();
    });
    searchInput.addEventListener('input', () => {
        paginationState.currentPage = 1;
        updateDisplay();
    });
    calcAvgSalaryBtn.addEventListener('click', calculateAverageSalary);
    namesUppercaseBtn.addEventListener('click', convertNamesToUppercase);
    themeToggleBtn.addEventListener('click', toggleTheme);
    exportCsvBtn.addEventListener('click', exportToCsv);
    sortableHeaders.forEach(header => header.addEventListener('click', handleSort));

    // Pagination
    prevPageBtn.addEventListener('click', () => {
        if (paginationState.currentPage > 1) {
            paginationState.currentPage--;
            renderTable();
            renderPagination();
        }
    });
    nextPageBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(currentEmployees.length / paginationState.pageSize);
        if (paginationState.currentPage < totalPages) {
            paginationState.currentPage++;
            renderTable();
            renderPagination();
        }
    });

    // Form
    addEmployeeBtn.addEventListener('click', () => {
        hideForm(); // Reset first
        showForm();
    });
    cancelBtn.addEventListener('click', hideForm);
    employeeForm.addEventListener('submit', handleFormSubmit);

    // Table action buttons (Edit/Delete)
    employeeTableBody.addEventListener('click', handleTableActions);


    // --- INITIALIZATION ---
    const initialize = () => {
        populateDepartments();
        updateDisplay();
    };
    
    initialize();
});
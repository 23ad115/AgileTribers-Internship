// --- DOM Element Selection ---
const hoursElem = document.getElementById('hours');
const minutesElem = document.getElementById('minutes');
const secondsElem = document.getElementById('seconds');
const sessionElem = document.getElementById('session');
const dateDisplayElem = document.getElementById('date-display');
const themeToggleBtn = document.getElementById('theme-toggle');
const timezoneSelect = document.getElementById('timezone');
const clockModule = document.getElementById('clock-module');
const stopwatchModule = document.getElementById('stopwatch-module');
const showClockBtn = document.getElementById('show-clock-btn');
const showStopwatchBtn = document.getElementById('show-stopwatch-btn');
const stopwatchDisplay = document.getElementById('stopwatch-display');
const startStopBtn = document.getElementById('start-stop-btn');
const resetBtn = document.getElementById('reset-btn');

// --- Clock and Date Functionality ---
let clockInterval;

function displayTime() {
    const selectedZone = timezoneSelect.value;
    // Use a robust method to get the date object for the selected time zone
    const now = selectedZone === 'local' 
        ? new Date() 
        : new Date(new Date().toLocaleString('en-US', { timeZone: selectedZone }));

    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();
    let session = 'AM';

    if (hours >= 12) {
        session = 'PM';
    }
    if (hours > 12) {
        hours -= 12;
    }
    if (hours === 0) {
        hours = 12;
    }

    hoursElem.innerText = String(hours).padStart(2, '0');
    minutesElem.innerText = String(minutes).padStart(2, '0');
    secondsElem.innerText = String(seconds).padStart(2, '0');
    sessionElem.innerText = session;

    // Display the date (only needs to be updated once, but this is simple)
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    dateDisplayElem.innerText = new Date().toLocaleDateString(undefined, options);
    
    // Update background based on local time of day
    updateBackground(new Date().getHours());
}

// Start clock initially
clockInterval = setInterval(displayTime, 1000);
displayTime();


// --- Background Changer based on Time of Day ---
let currentBgClass = '';
function updateBackground(hour) {
    let newBgClass = '';
    if (hour >= 5 && hour < 12) {
        newBgClass = 'morning';
    } else if (hour >= 12 && hour < 18) {
        newBgClass = 'afternoon';
    } else if (hour >= 18 && hour < 21) {
        newBgClass = 'evening';
    } else {
        newBgClass = 'night';
    }
    
    if (newBgClass !== currentBgClass) {
        document.body.classList.remove(currentBgClass);
        document.body.classList.add(newBgClass);
        currentBgClass = newBgClass;
    }
}


// --- Dark/Light Theme Toggle ---
themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    if (document.body.classList.contains('light-mode')) {
        themeToggleBtn.innerText = '🌙';
        localStorage.setItem('theme', 'light');
    } else {
        themeToggleBtn.innerText = '☀️';
        localStorage.setItem('theme', 'dark');
    }
});

// Check for saved theme in localStorage on page load
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') {
    document.body.classList.add('light-mode');
    themeToggleBtn.innerText = '🌙';
}


// --- Time Zone Selector ---
timezoneSelect.addEventListener('change', displayTime);


// --- Stopwatch Functionality ---
let stopwatchInterval;
let stopwatchTime = 0;
let stopwatchRunning = false;

function formatStopwatchTime(time) {
    const ms = Math.floor((time % 1000) / 10);
    const seconds = Math.floor((time / 1000) % 60);
    const minutes = Math.floor((time / (1000 * 60)) % 60);
    const hours = Math.floor((time / (1000 * 60 * 60)) % 24);
    
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}:${String(ms).padStart(2, '0')}`;
}

startStopBtn.addEventListener('click', () => {
    if (stopwatchRunning) {
        // Stop the stopwatch
        clearInterval(stopwatchInterval);
        startStopBtn.innerText = 'Start';
    } else {
        // Start the stopwatch
        const startTime = Date.now() - stopwatchTime;
        stopwatchInterval = setInterval(() => {
            stopwatchTime = Date.now() - startTime;
            stopwatchDisplay.innerText = formatStopwatchTime(stopwatchTime);
        }, 10);
        startStopBtn.innerText = 'Stop';
    }
    stopwatchRunning = !stopwatchRunning;
});

resetBtn.addEventListener('click', () => {
    clearInterval(stopwatchInterval);
    stopwatchRunning = false;
    stopwatchTime = 0;
    stopwatchDisplay.innerText = formatStopwatchTime(0);
    startStopBtn.innerText = 'Start';
});


// --- Module (Clock/Stopwatch) Switching ---
function switchToClock() {
    stopwatchModule.classList.remove('active');
    showStopwatchBtn.classList.remove('active');
    clockModule.classList.add('active');
    showClockBtn.classList.add('active');
    
    // Resume the clock interval if it was stopped
    if (!clockInterval) {
        clockInterval = setInterval(displayTime, 1000);
    }
}

function switchToStopwatch() {
    clockModule.classList.remove('active');
    showClockBtn.classList.remove('active');
    stopwatchModule.classList.add('active');
    showStopwatchBtn.classList.add('active');
    
    // It's good practice to stop the clock interval when not visible
    clearInterval(clockInterval);
    clockInterval = null;
}

showClockBtn.addEventListener('click', switchToClock);
showStopwatchBtn.addEventListener('click', switchToStopwatch);
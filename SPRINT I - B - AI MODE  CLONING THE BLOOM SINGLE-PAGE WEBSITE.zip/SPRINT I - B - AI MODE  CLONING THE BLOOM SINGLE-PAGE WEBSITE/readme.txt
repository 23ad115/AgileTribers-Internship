Bloom Website Clone (Single Page)

A simple clone of the Bloom website built using only HTML and CSS.  
All code is in one `index.html` file — no external CSS, JS, or images.

 Features

- Header with logo and nav bar  
- Hero section with text, button, and image  
- Services section (3 cards)  
- Footer with posts, about, and social links

Tech Used

- HTML for structure  
- CSS for styling  

 How to Run

1. Copy and paste the code into a file named `index.html`  
2. Open it in your browser  
3. Done!


AI Used

Gemini 2.5 Pro Preview by Google AI Studio


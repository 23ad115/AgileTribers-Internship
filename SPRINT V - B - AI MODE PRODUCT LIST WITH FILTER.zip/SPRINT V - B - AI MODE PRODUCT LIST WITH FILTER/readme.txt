Advanced React Product List

This is an interactive and feature-rich product listing application built with React and Vite. It demonstrates a modern frontend setup with advanced user experience features like real-time search, sorting, dark mode, and animations.

✨ Features

This application is packed with modern features to provide a smooth and engaging user experience:

🔍 Search Bar: Instantly find products by name with a real-time search filter.

🗂️ Category Filtering: Filter the product list by categories, with dynamic product counts.

↕️ Sorting Options: Sort products by price (low to high, high to low) or by rating.

📄 Pagination: A simple pagination system to navigate through long lists of products.

🛒 Add to Cart: A functional "Add to Cart" button with a visual count in the header.

🔖 Discount Badges: Products on sale are clearly marked with a discount percentage.

🔲 View Toggle: Switch between a compact Grid View and a detailed List View.

🖱️ Product Detail Modal: Click on any product card to open a modal with more details.

☀️/🌙 Dark Mode: Toggle between a light and dark theme, with your preference saved.

❤️ Favorite Products: Mark products as favorites, which persists across sessions.

🎬 Animated Transitions: Smooth animations for filtering, view changes, and modal pop-ups, powered by Framer Motion.

🛠️ Tech Stack

Framework: React

Build Tool: Vite

Animation: Framer Motion

Styling: Plain CSS with variables for theming.

🚀 Getting Started

To run this project locally, follow these simple steps:

Clone the repository:

Generated bash
git clone <your-repository-url>
cd <repository-folder>


Install dependencies:
This will install React, Vite, Framer Motion, and other necessary packages.

npm install

Run the development server:
This will start the application on http://localhost:5173.

npm run dev

IGNORE_WHEN_COPYING_END
🤖 AI Collaboration

A significant portion of this project was developed in collaboration with an AI assistant.

AI Name: Google studio AI

The AI was instrumental in the rapid development and implementation of numerous features. Its contributions include:

Generating boilerplate code for new React components (Pagination, Modal, SortOptions, etc.).

Writing the core logic for filtering, sorting, and state management in App.jsx.

Implementing the dark mode theme switcher and the CSS variable structure.

Integrating the framer-motion library to add fluid animations and transitions.

Debugging issues, such as resolving package import errors.

This project serves as a demonstration of a successful human-AI partnership in modern software development.
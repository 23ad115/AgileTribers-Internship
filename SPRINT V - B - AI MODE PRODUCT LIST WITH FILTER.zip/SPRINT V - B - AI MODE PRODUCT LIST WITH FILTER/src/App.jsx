import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';

import Header from './components/Header';
import ProductList from './components/ProductList';
import FilterMenu from './components/FilterMenu';
import SearchBar from './components/SearchBar';
import SortOptions from './components/SortOptions';
import Pagination from './components/Pagination';
import ProductModal from './components/ProductModal';

import './style.css';

// Updated Product Data with discounts
const productData = [
  { id: 1, title: 'React Essentials', price: 29.99, category: 'Books', rating: 4.8, stock: 20 },
  { id: 2, title: 'Wireless Mouse', price: 49.99, category: 'Electronics', rating: 4.5, stock: 35, discount: 10 },
  { id: 3, title: 'Cotton T-Shirt', price: 19.99, category: 'Clothing', rating: 4.2, stock: 50 },
  { id: 4, title: 'JavaScript: The Good Parts', price: 24.50, category: 'Books', rating: 4.6, stock: 0 },
  { id: 5, title: 'Noise-Cancelling Headphones', price: 199.99, category: 'Electronics', rating: 4.9, stock: 12, discount: 15 },
  { id: 6, title: 'Denim Jeans', price: 79.99, category: 'Clothing', rating: 4.7, stock: 25 },
  { id: 7, title: 'OLED 4K TV', price: 1299.00, category: 'Electronics', rating: 3.9, stock: 5 },
  { id: 8, title: 'The Hobbit', price: 14.99, category: 'Books', rating: 4.9, stock: 30, discount: 5 },
  { id: 9, title: 'Leather Jacket', price: 249.50, category: 'Clothing', rating: 4.1, stock: 0 },
  { id: 10, title: 'Smartwatch', price: 349.00, category: 'Electronics', rating: 4.7, stock: 18 }
];

const categories = ['All', 'Electronics', 'Books', 'Clothing'];
const ITEMS_PER_PAGE = 6;

function App() {
  // State Management
  const [theme, setTheme] = useState('light');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortOption, setSortOption] = useState('default');
  const [viewMode, setViewMode] = useState('grid');
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem('favorites')) || []);
  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);

  // Theme Toggler
  useEffect(() => {
    document.body.className = theme;
  }, [theme]);
  
  const toggleTheme = () => setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));

  // Favorites Handler
  useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (productId) => {
    setFavorites(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId) 
        : [...prev, productId]
    );
  };
  
  // Cart Handler
  const addToCart = (product) => {
    setCart(prev => [...prev, product]);
    alert(`${product.title} added to cart!`);
  };

  // Logic for Filtering, Sorting, and Pagination
  const processedProducts = productData
    .filter(product => {
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => {
      switch (sortOption) {
        case 'price-asc': return a.price - b.price;
        case 'price-desc': return b.price - a.price;
        case 'rating-desc': return b.rating - a.rating;
        default: return 0;
      }
    });

  const totalPages = Math.ceil(processedProducts.length / ITEMS_PER_PAGE);
  const paginatedProducts = processedProducts.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );
  
  // Reset to page 1 if filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory, searchQuery, sortOption]);

  return (
    <div className="app-container">
      <Header 
        theme={theme}
        onToggleTheme={toggleTheme}
        cartCount={cart.length}
      />
      
      <main>
        <div className="controls-container">
          <SearchBar searchQuery={searchQuery} onSearchChange={(e) => setSearchQuery(e.target.value)} />
          <SortOptions 
            sortOption={sortOption} 
            onSortChange={(e) => setSortOption(e.target.value)} 
            viewMode={viewMode}
            onViewChange={setViewMode}
          />
        </div>

        <FilterMenu
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          products={productData}
        />
        
        <ProductList
          products={paginatedProducts}
          viewMode={viewMode}
          favorites={favorites}
          onToggleFavorite={toggleFavorite}
          onAddToCart={addToCart}
          onProductClick={setSelectedProduct}
        />
        
        <Pagination 
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      </main>

      <AnimatePresence>
        {selectedProduct && (
          <ProductModal 
            product={selectedProduct} 
            onClose={() => setSelectedProduct(null)}
            onAddToCart={addToCart}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
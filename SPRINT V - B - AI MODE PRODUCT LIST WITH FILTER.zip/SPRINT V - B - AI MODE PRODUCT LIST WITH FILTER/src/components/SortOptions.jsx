import React from 'react';

function SortOptions({ sortOption, onSortChange, viewMode, onViewChange }) {
  return (
    <div className="sort-view-controls">
      <select value={sortOption} onChange={onSortChange} className="sort-dropdown" aria-label="Sort products">
        <option value="default">Sort by: Default</option>
        <option value="price-asc">Price: Low to High</option>
        <option value="price-desc">Price: High to Low</option>
        <option value="rating-desc">Rating: High to Low</option>
      </select>
      <div className="view-toggle">
        <button onClick={() => onViewChange('list')} className={viewMode === 'list' ? 'active' : ''} aria-label="List view">☰</button>
        <button onClick={() => onViewChange('grid')} className={viewMode === 'grid' ? 'active' : ''} aria-label="Grid view">⊞</button>
      </div>
    </div>
  );
}

export default SortOptions;
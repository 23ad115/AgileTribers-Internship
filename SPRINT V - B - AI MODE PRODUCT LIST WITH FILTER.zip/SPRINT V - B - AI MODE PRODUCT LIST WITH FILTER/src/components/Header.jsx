import React from 'react';
import logo from '../assets/logo.png';

function Header({ theme, onToggleTheme, cartCount }) {
  return (
    <header className="app-header">
      <div className="header-left">
        <img src={logo} alt="InternTribe Logo" className="logo" />
        <h1>Product List</h1>
      </div>
      <div className="header-right">
        <div className="theme-switcher" onClick={onToggleTheme}>
          <div className={`slider ${theme}`}></div>
          <span className="icon">☀️</span>
          <span className="icon">🌙</span>
        </div>
        <div className="cart-icon">
          🛒
          {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
        </div>
      </div>
    </header>
  );
}

export default Header;
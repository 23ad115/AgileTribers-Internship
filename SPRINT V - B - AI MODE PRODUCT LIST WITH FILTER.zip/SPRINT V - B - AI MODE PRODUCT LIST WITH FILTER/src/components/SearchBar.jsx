import React from 'react';

/**
 * A controlled input component for searching products.
 * @param {object} props - The component props.
 * @param {string} props.searchQuery - The current value of the search input.
 * @param {function} props.onSearchChange - The callback function to call when the input value changes.
 */
function SearchBar({ searchQuery, onSearchChange }) {
  return (
    <div className="search-bar">
      <input
        type="text"
        placeholder="Search for products by name..."
        value={searchQuery}
        onChange={onSearchChange}
        aria-label="Search products"
      />
    </div>
  );
}

export default SearchBar;
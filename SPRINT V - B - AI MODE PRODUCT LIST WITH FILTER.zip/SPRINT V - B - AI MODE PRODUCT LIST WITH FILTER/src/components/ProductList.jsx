import React from 'react';
import ProductCard from './ProductCard';
import { motion, AnimatePresence } from 'framer-motion';

function ProductList({ products, viewMode, favorites, onToggleFavorite, onAddToCart, onProductClick }) {
  if (products.length === 0) {
    return <p className="fallback-message">No products found matching your criteria.</p>;
  }

  const listClassName = `product-list-wrapper ${viewMode}`;

  return (
    <div className={listClassName}>
      <AnimatePresence>
        {products.map(product => (
          <ProductCard 
            key={product.id} 
            product={product} 
            isFavorite={favorites.includes(product.id)}
            onToggleFavorite={onToggleFavorite}
            onAddToCart={onAddToCart}
            onProductClick={onProductClick}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

export default ProductList;
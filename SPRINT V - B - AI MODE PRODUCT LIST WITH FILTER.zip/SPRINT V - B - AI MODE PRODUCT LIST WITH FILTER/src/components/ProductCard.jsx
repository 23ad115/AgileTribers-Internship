import React from 'react';
import { motion } from 'framer-motion';

function ProductCard({ product, isFavorite, onToggleFavorite, onAddToCart, onProductClick }) {
  const { title, price, category, rating, stock, discount } = product;

  const categoryClass = `category-${category.toLowerCase()}`;
  const highlightClass = rating > 4.5 ? 'highlight' : '';
  const outOfStockClass = stock === 0 ? 'out-of-stock-card' : '';
  
  const discountedPrice = discount ? price * (1 - discount / 100) : price;

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
  };

  // Prevent event bubbling from buttons to the card's main click handler
  const handleButtonClick = (e, action) => {
    e.stopPropagation();
    action();
  };

  return (
    <motion.div
      className={`product-card ${categoryClass} ${highlightClass} ${outOfStockClass}`}
      onClick={() => onProductClick(product)}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
      layout // This animates the layout changes (e.g., filtering)
      transition={{ duration: 0.3 }}
    >
      <div className="card-header">
        {discount && <div className="discount-badge">{discount}% OFF</div>}
        {stock === 0 && <span className="stock-badge">Out of Stock</span>}
      </div>
      
      <div className="product-details">
        <h3 className="product-title">{title}</h3>
        <p className="product-price">
          {discount && <span className="original-price">₹{price.toFixed(2)}</span>}
          ₹{discountedPrice.toFixed(2)}
        </p>
        <p className="product-category">Category: {category}</p>
        <p className="product-rating">Rating: {rating} / 5 {rating > 4.5 && '⭐'}</p>
      </div>
      
      <div className="product-actions">
        <button 
          className="favorite-btn" 
          onClick={(e) => handleButtonClick(e, () => onToggleFavorite(product.id))}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          {isFavorite ? '❤️' : '🤍'}
        </button>
        <button 
          className="add-to-cart-btn" 
          onClick={(e) => handleButtonClick(e, () => onAddToCart(product))}
          disabled={stock === 0}
        >
          Add to Cart
        </button>
      </div>
    </motion.div>
  );
}

export default ProductCard;
import React from 'react';
import { motion } from 'framer-motion';

function ProductModal({ product, onClose, onAddToCart }) {
  const { title, price, category, rating, stock, discount } = product;
  const discountedPrice = discount ? price * (1 - discount / 100) : price;

  const handleContentClick = (e) => e.stopPropagation();

  return (
    <motion.div
      className="modal-overlay"
      onClick={onClose}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="modal-content"
        onClick={handleContentClick}
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      >
        <button className="close-modal-btn" onClick={onClose}>×</button>
        <h2>{title}</h2>
        <div className="modal-body">
            <p className="product-category"><strong>Category:</strong> {category}</p>
            <p className="product-rating"><strong>Rating:</strong> {rating} / 5 {rating > 4.5 && '⭐'}</p>
            <p className="product-stock"><strong>Stock:</strong> {stock > 0 ? `${stock} available` : 'Out of Stock'}</p>
            <p className="product-price">
              {discount && <span className="original-price">₹{price.toFixed(2)}</span>}
              ₹{discountedPrice.toFixed(2)}
              {discount && <span className="discount-badge-modal">{discount}% OFF</span>}
            </p>
            <p>This is a detailed description of the product. It's a high-quality item perfect for your needs, combining both style and functionality.</p>
        </div>
        <button 
          className="add-to-cart-btn modal-cart-btn" 
          onClick={() => onAddToCart(product)}
          disabled={stock === 0}
        >
          Add to Cart
        </button>
      </motion.div>
    </motion.div>
  );
}

export default ProductModal;
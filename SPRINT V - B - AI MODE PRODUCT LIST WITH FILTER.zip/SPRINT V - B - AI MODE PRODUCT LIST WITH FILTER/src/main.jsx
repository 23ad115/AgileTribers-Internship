import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './style.css'

// Note: React.StrictMode is removed to prevent double-rendering on mount,
// which can sometimes interfere with initial animations from framer-motion.
// You can re-enable it for debugging purposes.
ReactDOM.createRoot(document.getElementById('root')).render(
    <App />
)
/*
Note on Edit and Delete Logic:
The delete button logic works by getting the button's parent element (the list item) and removing it directly from the DOM.
The edit button logic is a two-state process: it first replaces the task text with an input field to allow editing. On the second click ('Save'), it updates the text with the new value from the input and reverts the UI back to its original state.
*/

document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');

    function addTask() {
        const taskText = taskInput.value.trim();

        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        const li = document.createElement('li');
        li.className = 'task-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.addEventListener('change', () => {
            li.classList.toggle('completed');
            checkbox.blur(); 
        });

        const span = document.createElement('span');
        span.className = 'task-text';
        span.textContent = taskText;

        const buttonsDiv = document.createElement('div');
        buttonsDiv.className = 'task-buttons';

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';
        editBtn.textContent = 'Edit';
        editBtn.addEventListener('click', () => editTask(li, span, editBtn));

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-btn';
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', () => {
            taskList.removeChild(li);
        });

        buttonsDiv.appendChild(editBtn);
        buttonsDiv.appendChild(deleteBtn);

        li.appendChild(checkbox);
        li.appendChild(span);
        li.appendChild(buttonsDiv);
        
        taskList.appendChild(li);

        taskInput.value = '';
        taskInput.focus();
    }
    
    function editTask(li, span, editBtn) {
        if (editBtn.textContent === 'Edit') {
            const currentText = span.textContent;
            const editInput = document.createElement('input');
            editInput.type = 'text';
            editInput.value = currentText;
            editInput.className = 'task-text';
            
            li.replaceChild(editInput, span);
            editInput.focus();
            
            editBtn.textContent = 'Save';
        } else {
            const editInput = li.querySelector('input[type="text"]');
            const newText = editInput.value.trim();

            if (newText) {
                span.textContent = newText;
                li.replaceChild(span, editInput);
                editBtn.textContent = 'Edit';
            } else {
                alert("Task text cannot be empty.");
            }
        }
    }
    
    addTaskBtn.addEventListener('click', addTask);
    
    taskInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });
});
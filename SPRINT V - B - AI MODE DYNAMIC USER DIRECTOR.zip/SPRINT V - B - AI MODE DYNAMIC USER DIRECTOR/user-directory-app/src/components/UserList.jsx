import React from 'react';
import UserCard from './UserCard';

const UserList = ({ users }) => {
  const roleCounts = users.reduce((acc, user) => {
    acc[user.role] = (acc[user.role] || 0) + 1;
    return acc;
  }, {});
  
  if (!users || users.length === 0) {
    return <p className="fallback-message">No users found. Try adjusting your search.</p>;
  }

  return (
    <div>
      <div className="role-counts">
        {Object.entries(roleCounts).map(([role, count]) => (
          <span key={role}>{role}s: {count}</span>
        ))}
      </div>
      <div className="user-list-container">
        {users.map(user => (
          <UserCard key={user.id} {...user} />
        ))}
      </div>
    </div>
  );
};

export default UserList;
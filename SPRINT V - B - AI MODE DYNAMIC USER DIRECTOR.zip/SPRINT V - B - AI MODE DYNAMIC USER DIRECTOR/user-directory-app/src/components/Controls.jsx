import React from 'react';

const Controls = ({ 
  searchTerm, 
  onSearchChange, 
  roleFilter, 
  onRoleFilterChange, 
  onSort,
  sortConfig,
  theme, 
  onThemeToggle 
}) => {
  return (
    <div className="controls">
      <input
        type="text"
        placeholder="Search by name..."
        className="search-box"
        value={searchTerm}
        onChange={onSearchChange}
      />
      
      <select 
        className="filter-dropdown" 
        value={roleFilter} 
        onChange={onRoleFilterChange}
      >
        <option value="All">All Roles</option>
        <option value="Admin">Admin</option>
        <option value="Member">Member</option>
        <option value="Guest">Guest</option>
      </select>
      
      <div>
        <button 
          onClick={() => onSort('name')} 
          className={`sort-button ${sortConfig.key === 'name' ? 'active' : ''}`}
        >
          Sort by Name
        </button>
        <button 
          onClick={() => onSort('age')}
          className={`sort-button ${sortConfig.key === 'age' ? 'active' : ''}`}
        >
          Sort by Age
        </button>
      </div>

      <button onClick={onThemeToggle} className="theme-toggle">
        Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
      </button>
    </div>
  );
};

export default Controls;
import React, { useState, useEffect } from 'react';

const EditUserModal = ({ user, onSave, onClose }) => {
  const [formData, setFormData] = useState(user);

  useEffect(() => {
    setFormData(user);
  }, [user]);

  if (!user) {
    return null;
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>Edit User</h2>
        <form onSubmit={handleSubmit} className="modal-form">
          <label>Name</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} />
          <label>Email</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} />
          <label>Age</label>
          <input type="number" name="age" value={formData.age} onChange={handleChange} />
          <label>Role</label>
          <input type="text" name="role" value={formData.role} onChange={handleChange} />
          <label>Phone</label>
          <input type="tel" name="phone" value={formData.phone} onChange={handleChange} />
          <label>Address</label>
          <input type="text" name="address" value={formData.address} onChange={handleChange} />

          <div className="modal-actions">
            <button type="button" onClick={onClose} className="delete-button">Cancel</button>
            <button type="submit" className="edit-button">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditUserModal;